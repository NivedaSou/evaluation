<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class MatiereController extends AbstractController
{
    /**
     * @Route("/matiere", name="matiere")
     */
    public function index(): Response
    {
        $em = $this->getDoctrine()->getManager(); 

        $matiere = new Matiere(); 
        $form = $this->createForm(MatiereType::class, $matiere);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){ 
            $em->persist($matiere);
            $em->flush(); 

            $this->addFlash(
                'success',
                $trans->trans('matiere.ajoutee')
            );
        }

        $matieres = $em->getRepository(Matiere::class)->findAll();

    }

    /**
     * @Route("/matiere/{id}", name="show")
     */
    public function show(Matiere $matiere = null, Request $request){
        if($matiere == null){
            // Il n'a pas trouvé de catégorie
            $this->addFlash(
                'erreur',
                'Catégorie introuvable'
            );
            return $this->redirectToRoute('matiere');
        }

        $form = $this->createForm(MatiereType::class, $matiere);
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            $em = $this->getDoctrine()->getManager();
            $em->persist($matiere);
            $em->flush();

            $this->addFlash('success', 'Catégorie modifiée');
        }

        return $this->render('matiere/show.html.twig', [
            'matiere' => $matiere,
            'maj' => $form->createView()
        ]);
    }

    /**
     * @Route("/matiere/delete/{id}", name="delete")
     */
    public function delete(Matiere $matiere = null){
        if($matiere == null){
            $this->addFlash('error', 'Catégorie introuvable');
            return $this->redirectToRoute('matiere');
        }

        $em = $this->getDoctrine()->getManager();
        $em->remove($matiere);
        $em->flush();

        $this->addFlash('success', 'Catégorie supprimée');
        return $this->redirectToRoute('categorie');
    }
}
